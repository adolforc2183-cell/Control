#!/usr/bin/env bash
set -e
D=android/app/src/main/java/com/controlremoto/samsung
mkdir -p "$D"
cp native/MainActivity.java "$D/MainActivity.java"
cp native/WolPlugin.java "$D/WolPlugin.java"
