package com.controlremoto.samsung;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(WolPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
