package com.controlremoto.samsung;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

@CapacitorPlugin(name = "Wol")
public class WolPlugin extends Plugin {

    @PluginMethod
    public void send(final PluginCall call) {
        final String mac = call.getString("mac");
        final String broadcast = call.getString("broadcast", "255.255.255.255");
        if (mac == null) { call.reject("Falta la MAC"); return; }

        new Thread(() -> {
            try {
                String[] hex = mac.split("[:\\-]");
                if (hex.length != 6) throw new IllegalArgumentException("MAC inválida");
                byte[] macBytes = new byte[6];
                for (int i = 0; i < 6; i++) macBytes[i] = (byte) Integer.parseInt(hex[i], 16);

                byte[] data = new byte[6 + 16 * 6];
                for (int i = 0; i < 6; i++) data[i] = (byte) 0xFF;
                for (int i = 6; i < data.length; i += 6) System.arraycopy(macBytes, 0, data, i, 6);

                String[] targets = { broadcast, "255.255.255.255" };
                int[] ports = { 9, 7 };
                try (DatagramSocket socket = new DatagramSocket()) {
                    socket.setBroadcast(true);
                    for (String t : targets) {
                        InetAddress addr = InetAddress.getByName(t);
                        for (int port : ports) {
                            socket.send(new DatagramPacket(data, data.length, addr, port));
                        }
                    }
                }
                call.resolve();
            } catch (Exception e) {
                call.reject(e.getMessage() != null ? e.getMessage() : e.toString());
            }
        }).start();
    }
}
